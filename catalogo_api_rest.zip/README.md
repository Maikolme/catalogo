# Catálogo de productos - API REST

Aplicación académica sencilla con interfaz web, inicio de sesión de administrador, CRUD de productos, SQLite, JWT y CORS.

## 1. Requisitos
- Python 3.10 o superior
- pip

## 2. Instalación
Abre una terminal en la carpeta del proyecto y ejecuta:

```bash
python -m venv venv
# Windows:
venv\\Scripts\\activate
# macOS/Linux:
source venv/bin/activate

pip install -r requirements.txt
python app.py
```

Abre en el navegador: http://127.0.0.1:5000

## 3. Credenciales de administrador (demo)
- Usuario: `admin`
- Contraseña: `Admin123*`

Después de iniciar sesión podrás crear, editar y eliminar productos. El token JWT dura 2 horas. El catálogo y la consulta de un producto son públicos.

**Seguridad:** son credenciales de demostración para el trabajo académico. Cámbialas antes de publicar el sitio en Internet. Puedes configurar `ADMIN_USER`, `ADMIN_PASSWORD`, `JWT_SECRET` y `DATABASE` como variables de entorno.

## 4. Rutas API

| Método | Ruta | Acceso |
|---|---|---|
| GET | `/api/productos` | Público |
| GET | `/api/productos/<id>` | Público |
| POST | `/api/productos` | JWT |
| PUT | `/api/productos/<id>` | JWT |
| DELETE | `/api/productos/<id>` | JWT |
| POST | `/api/auth/login` | Público |

Para POST, PUT y DELETE envía el encabezado:
`Authorization: Bearer TU_TOKEN`

Ejemplo de JSON:
```json
{
  "nombre": "Monitor",
  "descripcion": "Monitor LED de 24 pulgadas",
  "precio": 520000,
  "stock": 5
}
```

## 5. Códigos HTTP
- `200`: operación exitosa.
- `201`: producto creado.
- `400`: datos inválidos.
- `401`: falta un token o las credenciales/token no son válidos.
- `404`: producto o ruta no encontrada.
- `405`: método HTTP no permitido.

## 6. Estructura por capas

- `routes/`: recibe las solicitudes HTTP.
- `services/`: valida y prepara los datos.
- `repositories/`: consulta y modifica la base de datos.
- `middleware/`: protege rutas con JWT.
- `templates/` y `static/`: interfaz web.

## 7. Pruebas rápidas
1. Abre el sitio y consulta los productos sin iniciar sesión.
2. Inicia sesión con las credenciales demo.
3. Crea un producto y verifica que aparezca.
4. Edita el producto y cambia su stock.
5. Elimínalo.
6. Para probar la protección, intenta hacer POST sin el encabezado JWT: debe responder `401`.

La base de datos `catalogo.db` se crea automáticamente al iniciar la aplicación.
