from flask import Blueprint, request, jsonify, current_app
from datetime import datetime, timedelta, timezone
import jwt

auth_bp = Blueprint("auth", __name__)

@auth_bp.post("/login")
def login():
    data = request.get_json(silent=True) or {}
    username = data.get("usuario", "")
    password = data.get("password", "")
    if username != current_app.config["ADMIN_USER"] or password != current_app.config["ADMIN_PASSWORD"]:
        return jsonify({"error": "Usuario o contraseña incorrectos"}), 401
    token = jwt.encode({
        "sub": username,
        "exp": datetime.now(timezone.utc) + timedelta(hours=2)
    }, current_app.config["JWT_SECRET"], algorithm="HS256")
    return jsonify({"mensaje": "Inicio de sesión exitoso", "token": token, "usuario": username}), 200
