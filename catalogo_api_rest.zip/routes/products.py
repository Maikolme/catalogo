from flask import Blueprint, request, jsonify
from middleware.auth_required import token_required
from services.product_service import ProductService

products_bp = Blueprint("products", __name__)

@products_bp.get("")
def list_products():
    return jsonify(ProductService.list_products()), 200

@products_bp.get("/<int:product_id>")
def get_product(product_id):
    product = ProductService.get_product(product_id)
    if not product:
        return jsonify({"error": "Producto no encontrado"}), 404
    return jsonify(product), 200

@products_bp.post("")
@token_required
def create_product():
    data = request.get_json(silent=True)
    error = ProductService.validate(data)
    if error:
        return jsonify({"error": error}), 400
    return jsonify({"mensaje": "Producto creado", "producto": ProductService.create(data)}), 201

@products_bp.put("/<int:product_id>")
@token_required
def update_product(product_id):
    if not ProductService.get_product(product_id):
        return jsonify({"error": "Producto no encontrado"}), 404
    data = request.get_json(silent=True)
    error = ProductService.validate(data)
    if error:
        return jsonify({"error": error}), 400
    return jsonify({"mensaje": "Producto actualizado", "producto": ProductService.update(product_id, data)}), 200

@products_bp.delete("/<int:product_id>")
@token_required
def delete_product(product_id):
    if not ProductService.delete(product_id):
        return jsonify({"error": "Producto no encontrado"}), 404
    return jsonify({"mensaje": "Producto eliminado"}), 200
