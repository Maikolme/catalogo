let token = localStorage.getItem("catalogToken");
const $ = id => document.getElementById(id);
const money = value => new Intl.NumberFormat("es-CO",{style:"currency",currency:"COP",maximumFractionDigits:0}).format(value);
function setMessage(id, text, ok=false){$(id).textContent=text;$(id).className="message"+(ok?" ok":"");}
function updateSession(){
  $("loginPanel").hidden=!!token;
  $("adminArea").hidden=!token;
  $("logoutBtn").hidden=!token;
}
async function loadProducts(){
  const response=await fetch("/api/productos");
  const items=await response.json();
  $("products").innerHTML="";
  if(!items.length){$("products").textContent="Todavía no hay productos registrados.";return;}
  items.forEach(p=>{
    const article=document.createElement("article");article.className="product";
    const info=document.createElement("div");
    const title=document.createElement("h3");title.textContent=p.nombre;
    const desc=document.createElement("p");desc.textContent=p.descripcion||"Sin descripción";
    const stock=document.createElement("div");stock.className="stock";stock.textContent=`Existencias: ${p.stock}`;
    info.append(title,desc,stock);
    const right=document.createElement("div");
    const price=document.createElement("div");price.className="price";price.textContent=money(p.precio);right.append(price);
    if(token){
      const actions=document.createElement("div");actions.className="actions";
      const edit=document.createElement("button");edit.className="secondary";edit.textContent="Editar";edit.onclick=()=>editProduct(p);
      const del=document.createElement("button");del.className="danger";del.textContent="Eliminar";del.onclick=()=>deleteProduct(p.id);
      actions.append(edit,del);right.append(actions);
    }
    article.append(info,right);$("products").append(article);
  });
}
$("loginForm").addEventListener("submit",async e=>{
  e.preventDefault();setMessage("loginMessage","Verificando...");
  try{
    const res=await fetch("/api/auth/login",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({usuario:$("username").value,password:$("password").value})});
    const data=await res.json();if(!res.ok)throw new Error(data.error||"No se pudo iniciar sesión");
    token=data.token;localStorage.setItem("catalogToken",token);updateSession();await loadProducts();
  }catch(err){setMessage("loginMessage",err.message);}
});
$("logoutBtn").onclick=()=>{token=null;localStorage.removeItem("catalogToken");resetForm();updateSession();loadProducts();};
function resetForm(){$("productForm").reset();$("productId").value="";$("saveBtn").textContent="Agregar producto";$("cancelEdit").hidden=true;}
function editProduct(p){$("productId").value=p.id;$("name").value=p.nombre;$("description").value=p.descripcion;$("price").value=p.precio;$("stock").value=p.stock;$("saveBtn").textContent="Guardar cambios";$("cancelEdit").hidden=false;window.scrollTo({top:$("productForm").offsetTop+250,behavior:"smooth"});}
$("cancelEdit").onclick=resetForm;
$("productForm").addEventListener("submit",async e=>{
  e.preventDefault();const id=$("productId").value;
  const body={nombre:$("name").value,descripcion:$("description").value,precio:Number($("price").value),stock:Number($("stock").value)};
  try{
    const res=await fetch(id?`/api/productos/${id}`:"/api/productos",{method:id?"PUT":"POST",headers:{"Content-Type":"application/json","Authorization":`Bearer ${token}`},body:JSON.stringify(body)});
    const data=await res.json();if(!res.ok)throw new Error(data.error||"No se pudo guardar");
    setMessage("formMessage",data.mensaje,true);resetForm();await loadProducts();
  }catch(err){setMessage("formMessage",err.message);}
});
async function deleteProduct(id){
  if(!confirm("¿Seguro que deseas eliminar este producto?"))return;
  const res=await fetch(`/api/productos/${id}`,{method:"DELETE",headers:{"Authorization":`Bearer ${token}`}});
  const data=await res.json();if(!res.ok){alert(data.error||"Error al eliminar");return;}await loadProducts();
}
updateSession();loadProducts();
