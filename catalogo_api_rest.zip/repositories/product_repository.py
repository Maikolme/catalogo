from database import get_db

class ProductRepository:
    @staticmethod
    def all():
        db = get_db()
        rows = db.execute("SELECT * FROM productos ORDER BY id DESC").fetchall()
        db.close()
        return [dict(row) for row in rows]

    @staticmethod
    def get(product_id):
        db = get_db()
        row = db.execute("SELECT * FROM productos WHERE id = ?", (product_id,)).fetchone()
        db.close()
        return dict(row) if row else None

    @staticmethod
    def create(data):
        db = get_db()
        cur = db.execute(
            "INSERT INTO productos(nombre, descripcion, precio, stock) VALUES (?, ?, ?, ?)",
            (data["nombre"], data.get("descripcion", ""), data["precio"], data.get("stock", 0))
        )
        db.commit()
        product_id = cur.lastrowid
        db.close()
        return ProductRepository.get(product_id)

    @staticmethod
    def update(product_id, data):
        db = get_db()
        db.execute(
            "UPDATE productos SET nombre=?, descripcion=?, precio=?, stock=? WHERE id=?",
            (data["nombre"], data.get("descripcion", ""), data["precio"], data.get("stock", 0), product_id)
        )
        db.commit()
        db.close()
        return ProductRepository.get(product_id)

    @staticmethod
    def delete(product_id):
        db = get_db()
        cur = db.execute("DELETE FROM productos WHERE id=?", (product_id,))
        db.commit()
        deleted = cur.rowcount > 0
        db.close()
        return deleted
