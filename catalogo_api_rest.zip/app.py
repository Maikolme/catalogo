from flask import Flask, jsonify
from flask_cors import CORS
from config import Config
from database import init_db
from routes.web import web_bp
from routes.auth import auth_bp
from routes.products import products_bp

def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)
    CORS(app)
    init_db()
    app.register_blueprint(web_bp)
    app.register_blueprint(auth_bp, url_prefix="/api/auth")
    app.register_blueprint(products_bp, url_prefix="/api/productos")

    @app.errorhandler(404)
    def not_found(_):
        return jsonify({"error": "Recurso no encontrado"}), 404

    @app.errorhandler(405)
    def method_not_allowed(_):
        return jsonify({"error": "Método HTTP no permitido"}), 405

    return app

if __name__ == "__main__":
    create_app().run(debug=True, port=5000)
