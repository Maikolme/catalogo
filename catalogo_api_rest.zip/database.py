import sqlite3
from flask import current_app

def get_db():
    conn = sqlite3.connect(current_app.config["DATABASE"])
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = sqlite3.connect("catalogo.db")
    conn.execute("""
        CREATE TABLE IF NOT EXISTS productos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT NOT NULL,
            descripcion TEXT DEFAULT '',
            precio REAL NOT NULL CHECK(precio >= 0),
            stock INTEGER NOT NULL DEFAULT 0 CHECK(stock >= 0)
        )
    """)
    total = conn.execute("SELECT COUNT(*) FROM productos").fetchone()[0]
    if total == 0:
        conn.executemany(
            "INSERT INTO productos(nombre, descripcion, precio, stock) VALUES (?, ?, ?, ?)",
            [
                ("Teclado USB", "Teclado básico para computador", 45000, 12),
                ("Mouse inalámbrico", "Mouse óptico", 35000, 20),
                ("Memoria USB 32 GB", "Almacenamiento portátil", 28000, 8),
            ],
        )
    conn.commit()
    conn.close()
