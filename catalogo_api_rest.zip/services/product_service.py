from repositories.product_repository import ProductRepository

class ProductService:
    @staticmethod
    def validate(data):
        if not isinstance(data, dict):
            return "El cuerpo debe ser un objeto JSON"
        if not str(data.get("nombre", "")).strip():
            return "El nombre es obligatorio"
        try:
            price = float(data["precio"])
            stock = int(data.get("stock", 0))
            if price < 0 or stock < 0:
                return "El precio y el stock no pueden ser negativos"
        except (KeyError, TypeError, ValueError):
            return "Precio y stock deben ser números válidos"
        return None

    @staticmethod
    def clean(data):
        return {
            "nombre": str(data["nombre"]).strip(),
            "descripcion": str(data.get("descripcion", "")).strip(),
            "precio": float(data["precio"]),
            "stock": int(data.get("stock", 0))
        }

    @staticmethod
    def list_products():
        return ProductRepository.all()

    @staticmethod
    def get_product(product_id):
        return ProductRepository.get(product_id)

    @staticmethod
    def create(data):
        return ProductRepository.create(ProductService.clean(data))

    @staticmethod
    def update(product_id, data):
        return ProductRepository.update(product_id, ProductService.clean(data))

    @staticmethod
    def delete(product_id):
        return ProductRepository.delete(product_id)
