import os
class Config:
    SECRET_KEY = os.getenv("SECRET_KEY", "cambia-esta-clave-en-produccion")
    JWT_SECRET = os.getenv("JWT_SECRET", "clave-jwt-demo-catalogo")
    DATABASE = os.getenv("DATABASE", "catalogo.db")
    ADMIN_USER = os.getenv("ADMIN_USER", "admin")
    ADMIN_PASSWORD = os.getenv("ADMIN_PASSWORD", "Admin123*")
